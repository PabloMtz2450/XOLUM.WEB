const header=document.getElementById('header');
const progress=document.getElementById('progress');
const menuBtn=document.getElementById('menuBtn');
const mobileMenu=document.getElementById('mobileMenu');

function onScroll(){
  const y=window.scrollY;
  header.classList.toggle('scrolled',y>18);
  const doc=document.documentElement;
  const max=doc.scrollHeight-doc.clientHeight;
  progress.style.width=(max?y/max*100:0)+'%';
}
window.addEventListener('scroll',onScroll,{passive:true});
onScroll();

menuBtn.addEventListener('click',()=>{
  const open=mobileMenu.classList.toggle('open');
  document.body.classList.toggle('menu-open',open);
  menuBtn.textContent=open?'CERRAR':'MENÚ';
});
mobileMenu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{
  mobileMenu.classList.remove('open');
  document.body.classList.remove('menu-open');
  menuBtn.textContent='MENÚ';
}));

const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(!entry.isIntersecting)return;
    entry.target.classList.add('visible');
    observer.unobserve(entry.target);
  });
},{threshold:.15});

document.querySelectorAll('.reveal-mask,.fade').forEach(el=>observer.observe(el));
document.getElementById('year').textContent=new Date().getFullYear();
