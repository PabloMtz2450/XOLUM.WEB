(()=>{
  window.q = window.q || (s=>document.querySelector(s));
  window.qq = window.qq || (s=>[...document.querySelectorAll(s)]);
  const cookie=(name)=>Object.fromEntries(document.cookie.split(/;\s*/).filter(Boolean).map(x=>{const i=x.indexOf('=');return [decodeURIComponent(x.slice(0,i)),decodeURIComponent(x.slice(i+1))]}))[name]||'';
  window.xolumEsc = window.xolumEsc || ((v)=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])));
  window.money = window.money || ((n)=>new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(Number(n)||0));
  window.api = async (url,opt={})=>{
    const headers={...(opt.headers||{})};
    if(opt.body&&!headers['content-type'])headers['content-type']='application/json';
    if(!['GET','HEAD'].includes((opt.method||'GET').toUpperCase()))headers['x-xolum-csrf']=cookie('xolum_csrf');
    const r=await fetch(url,{...opt,headers,credentials:'same-origin',redirect:'follow'});
    if(r.status===401||r.status===403){location.href='/auth/login?returnTo='+encodeURIComponent(location.pathname+location.search);throw Error('Sesión requerida')}
    const j=await r.json().catch(()=>({ok:false,error:'Respuesta inválida'}));
    if(!r.ok||j.ok===false)throw Error(j.error||`HTTP ${r.status}`);
    return j;
  };
  window.toast = window.toast || ((t)=>alert(t));
  async function bootSession(){try{const s=await window.api('/api/session');document.querySelectorAll('.session-user').forEach(x=>x.textContent=`${s.user.name||s.user.email} · ${s.user.role}`)}catch{}}
  document.addEventListener('DOMContentLoaded',bootSession);
})();
