async function load(){try{const j=await api('/api/security-audit');q('#root').innerHTML=j.rows.length?j.rows.map(a=>`<div class=audit><b>${xolumEsc(a.event)}</b><small>${new Date(a.at).toLocaleString('es-MX')} · ${xolumEsc(a.actor?.email||a.actor?.role||'ANONYMOUS')}</small><div>${xolumEsc(a.resource)} · ${xolumEsc(a.result)}</div></div>`).join(''):'<p class=muted>Sin eventos de seguridad todavía.</p>'}catch(e){q('#root').innerHTML='<p class=bad>'+xolumEsc(e.message)+'</p>'}}
load();

document.querySelector("#reloadAudit")?.addEventListener("click",load);
