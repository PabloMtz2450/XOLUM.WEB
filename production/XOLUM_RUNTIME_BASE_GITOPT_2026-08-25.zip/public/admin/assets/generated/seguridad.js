(async()=>{
  const state=q('#securityState'), btn=q('#migrateBtn'), result=q('#migrateResult');
  async function refresh(){
    try{
      const r=await api('/api/security-status');
      const s=r.security||{}, cfg=s.configured||{};
      const rows=[
        ['Proveedor de identidad',s.auth_provider],['MFA',s.mfa_policy],['Sesión',s.session_cookie],['CSRF',s.csrf],['Almacenamiento',s.storage]
      ];
      state.innerHTML=rows.map(([k,v])=>`<div class="item"><b>${xolumEsc(k)}</b><span>${xolumEsc(v||'')}</span></div>`).join('')+
        '<h3>Variables requeridas</h3>'+Object.entries(cfg).map(([k,v])=>`<div class="item"><b>${xolumEsc(k)}</b><span>${v?'CONFIGURADA':'FALTA'}</span></div>`).join('');
    }catch(e){state.textContent=e.message}
  }
  btn.addEventListener('click',async()=>{
    if(!confirm('Esta operación reescribirá los stores heredados con cifrado de aplicación. Confirma que existe un respaldo y que deseas continuar.'))return;
    btn.disabled=true;result.textContent='Migrando…';
    try{const r=await api('/api/security-migrate',{method:'POST',body:'{}'});result.textContent=`Completado: ${r.migrated} objetos reescritos con cifrado.`;await refresh()}
    catch(e){result.textContent='Error: '+e.message}
    finally{btn.disabled=false}
  });
  await refresh();
})();
