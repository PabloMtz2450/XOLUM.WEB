fetch('/api/session',{credentials:'same-origin'}).then(r=>r.json()).then(j=>{if(!j.ok)location.replace('/auth/login?returnTo=/tienda/b2b/store.html')});
