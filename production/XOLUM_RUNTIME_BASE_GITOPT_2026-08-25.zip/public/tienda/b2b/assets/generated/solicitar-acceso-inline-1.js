document.querySelector('#send').onclick=async()=>{
 const data={action:'request',company:company.value.trim(),name:name.value.trim(),email:email.value.trim(),rfc:rfc.value.trim(),reason:reason.value.trim()};
 if(!data.company||!data.name||!data.email){alert('Completa empresa, nombre y correo.');return}
 const res=await fetch('/api/b2b-access',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});
 const j=await res.json();
 if(!res.ok){alert(j.error||'No fue posible enviar la solicitud.');return}
 msg.style.display='block';msg.textContent='Solicitud enviada a XOLUM. Folio: '+j.id;
};
