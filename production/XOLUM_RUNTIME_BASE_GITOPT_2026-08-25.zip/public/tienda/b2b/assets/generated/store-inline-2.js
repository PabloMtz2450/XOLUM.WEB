const _oldBuild=buildQuote; buildQuote=function(){_oldBuild();document.getElementById('qSubtotal2').textContent=document.getElementById('qSubtotal').textContent}
const _oldRender=renderRecommendation; renderRecommendation=function(){_oldRender(); if(state.selected){document.getElementById('modelSummary2').textContent='XOLUM '+state.selected.name+' · '+state.selected.size}}
