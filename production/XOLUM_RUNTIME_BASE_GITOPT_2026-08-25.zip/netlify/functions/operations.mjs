import { secureGet,secureSet } from "./_secure-store.mjs";
import crypto from "node:crypto";
import { json, requireAdmin,sessionInfo } from "./_auth.mjs";import {auditEvent} from "./_audit.mjs";
const STORE="xolum-operations-v80", KEY="operations-v1";
const now=()=>new Date().toISOString();
const rid=p=>`${p}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
const defaults=()=>({
  suppliers:[],
  price_lists:[
    {code:"B2C_PUBLIC",name:"Lista Pública B2C",channel:"B2C",active:true,margin_target:35,description:"Precio público del catálogo XOLUM."},
    {code:"B2B_STANDARD",name:"B2B Estándar",channel:"B2B",active:true,margin_target:30,description:"Lista empresarial estándar."},
    {code:"B2B_VOLUME",name:"B2B Volumen",channel:"B2B",active:true,margin_target:24,description:"Volumen y compras recurrentes."},
    {code:"B2B_SPECIAL_A",name:"Especial Cliente A",channel:"B2B",active:true,margin_target:22,description:"Lista especial parametrizable."},
    {code:"B2B_CONTRACT",name:"Contractual",channel:"B2B",active:true,margin_target:18,description:"Acuerdos contractuales."},
    {code:"PROMO",name:"Promocional",channel:"B2C/B2B",active:false,margin_target:15,description:"Campañas temporales."}
  ],
  settings:{currency:"MXN",iva_pct:16,hide_supplier_from_customer:true,default_package_rule:"1 unidad de venta = 1 empaque definido por SKU",order_from:"tupedido@xolum.com.mx",brand_rule:"El cliente siempre ve XOLUM, nunca el proveedor."},
  audit:[],updated_at:now()
});
async function read(){return await secureGet(STORE,KEY,defaults())}
async function write(d){d.updated_at=now();await secureSet(STORE,KEY,d);return d;}
function audit(d,type,detail,actor="ADMIN"){d.audit.unshift({id:rid("AUD"),type,detail,actor,at:now()});d.audit=d.audit.slice(0,1500);}
export default async(req)=>{
 const denied=requireAdmin(req);if(denied)return denied;
 if(req.method==="GET")return json({ok:true,...await read()});
 if(req.method!=="POST")return json({ok:false,error:"Método no permitido"},405);
 let b;try{b=await req.json()}catch{return json({ok:false,error:"JSON inválido"},400)}
 const d=await read(),a=String(b.action||""),actor=sessionInfo(req)?.email||"ADMIN";
 if(a==="saveSupplier"){
   const s=b.supplier||{};let x=d.suppliers.find(z=>z.id===s.id);
   if(!x){x={id:rid("SUP"),created_at:now()};d.suppliers.push(x)}
   Object.assign(x,{name:String(s.name||"").trim(),status:s.status||"active",category:s.category||"",contact:s.contact||"",email:s.email||"",phone:s.phone||"",website:s.website||"",lead_time_days:Number(s.lead_time_days||0)||null,payment_terms:s.payment_terms||"",shipping_model:s.shipping_model||"",notes:s.notes||"",updated_at:now()});
   audit(d,"SUPPLIER_SAVE",`${x.id} · ${x.name}`,actor);await write(d);await auditEvent(req,"SUPPLIER_SAVE","supplier","OK",{supplier_id:x.id});return json({ok:true,supplier:x});
 }
 if(a==="deleteSupplier"){const before=d.suppliers.length;d.suppliers=d.suppliers.filter(x=>x.id!==b.id);audit(d,"SUPPLIER_DELETE",String(b.id||""),actor);await write(d);await auditEvent(req,"SUPPLIER_DELETE","supplier","OK",{supplier_id:b.id});return json({ok:true,deleted:before-d.suppliers.length});}
 if(a==="savePriceLists"){if(!Array.isArray(b.price_lists))return json({ok:false,error:"price_lists[] requerido"},400);d.price_lists=b.price_lists;audit(d,"PRICE_LISTS_SAVE",`${d.price_lists.length} listas`,actor);await write(d);await auditEvent(req,"PRICE_LISTS_SAVE","price-lists","OK",{count:d.price_lists.length});return json({ok:true,count:d.price_lists.length});}
 if(a==="saveSettings"){d.settings={...d.settings,...(b.settings||{})};audit(d,"SETTINGS_SAVE","Configuración comercial actualizada",actor);await write(d);await auditEvent(req,"SETTINGS_SAVE","settings","OK");return json({ok:true,settings:d.settings});}
 if(a==="audit"){audit(d,String(b.type||"MANUAL"),String(b.detail||""),String(b.actor||"ADMIN"));await write(d);return json({ok:true});}
 return json({ok:false,error:"Acción no soportada"},400);
};
export const config={path:"/api/operations",rateLimit:{windowLimit:100,windowSize:60,aggregateBy:["ip","domain"]}};
