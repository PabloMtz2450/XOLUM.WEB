import crypto from "node:crypto";
import {randomToken} from "./_auth.mjs";
import {allowedAppOrigin} from "./_origin.mjs";

const c=(n,v)=>`${n}=${encodeURIComponent(v)}; Path=/; Max-Age=600; HttpOnly; Secure; SameSite=Lax`;

export default async(req)=>{
  try{
    const domain=process.env.AUTH0_DOMAIN;
    const client=process.env.AUTH0_CLIENT_ID;
    if(!domain||!client)return new Response("Autenticación no configurada",{status:503});

    const site=allowedAppOrigin(req);
    const u=new URL(req.url);
    const ret=u.searchParams.get("returnTo")||"/";
    if(!ret.startsWith("/")||ret.startsWith("//"))return new Response("returnTo inválido",{status:400});

    const state=randomToken(24),nonce=randomToken(24),verifier=randomToken(48);
    const challenge=crypto.createHash("sha256").update(verifier).digest("base64url");
    const p=new URLSearchParams({
      response_type:"code",
      client_id:client,
      redirect_uri:`${site}/auth/callback`,
      scope:"openid profile email",
      state,nonce,
      code_challenge:challenge,
      code_challenge_method:"S256",
      prompt:"login"
    });

    const h=new Headers({
      location:`https://${domain}/authorize?${p}`,
      "cache-control":"no-store"
    });
    for(const x of [
      c("xolum_oauth_state",state),
      c("xolum_oauth_nonce",nonce),
      c("xolum_oauth_pkce",verifier),
      c("xolum_return_to",ret)
    ]) h.append("set-cookie",x);

    return new Response(null,{status:302,headers:h});
  }catch(e){
    return new Response(`Inicio de sesión rechazado: ${e.message}`,{
      status:400,
      headers:{"cache-control":"no-store","content-type":"text/plain; charset=utf-8"}
    });
  }
};

export const config={
  path:"/auth/login",
  rateLimit:{windowLimit:20,windowSize:60,aggregateBy:["ip","domain"]}
};
