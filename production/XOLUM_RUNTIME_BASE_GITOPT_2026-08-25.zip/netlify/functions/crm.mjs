import { getStore } from "@netlify/blobs";
import { secureGet,secureSet,secureDelete } from "./_secure-store.mjs";
import crypto from "node:crypto";
import customerSeed from "./_data/customer-seed.mjs";
import { json, requireAdmin } from "./_auth.mjs";

const STORE="xolum-crm-v70", KEY="crm-v1";
const STAGES=["PROSPECTO","CONTACTADO","INTERES","COTIZACION","NEGOCIACION","GANADO","PERDIDO"];
const now=()=>new Date().toISOString();
const id=(p)=>`${p}-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
const clean=v=>String(v??"").trim();
const lower=v=>clean(v).toLowerCase();
const arr=v=>Array.isArray(v)?v:[];

function blank(){return {prospects:[],contacts:[],activities:[],opportunities:[],updated_at:now()};}
async function read(){return await secureGet(STORE,KEY,blank());}
async function write(data){data.updated_at=now();await secureSet(STORE,KEY,data);return data;}
function safeStage(v){v=clean(v).toUpperCase();return STAGES.includes(v)?v:"PROSPECTO";}
function num(v){const n=Number(String(v??"").replace(/[$,]/g,""));return Number.isFinite(n)?n:0;}
function bool(v){return [true,1,"1","true","sí","si","yes"].includes(typeof v==="string"?v.toLowerCase():v);}
function prospectPublic(p){return {...p};}

function matrixProspect(r){
 const domain=lower(r.domain||r["Dominio raíz"]||r["Dominio"]); if(!domain)return null;
 return {
  domain,
  name:clean(r.name||r["Organizaciones ejemplo"])||domain.split(".")[0].toUpperCase(),
  classification:clean(r.classification||r["Clasificación PYME"]), confidence:clean(r.confidence||r["Confianza"]),
  reason:clean(r.reason||r["Motivo"]), web_validated:bool(r.web_validated||r["WEB VALIDADA"]),
  web:clean(r.web||r["URL WEB VALIDADA"]), web_status:clean(r.web_status||r["Estado web"]),
  sector:clean(r.sector||r["Sector inferido"]), sector_confidence:clean(r.sector_confidence||r["Confianza sector"]),
  contact_hint:clean(r.contact_hint||r["Contacto recomendado"]), offer:clean(r.offer||r["Oferta principal XOLUM"]),
  secondary_offer:clean(r.secondary_offer||r["Oferta secundaria XOLUM"]), entry_product:clean(r.entry_product||r["Producto de entrada"]),
  argument:clean(r.argument||r["Argumento comercial"]), route:clean(r.route||r["Ruta comercial"]),
  priority:clean(r.priority||r["Prioridad comercial"])||"Media", source:clean(r.source||r["Fuente giro"]),
  research_status:clean(r.research_status||r["Estatus investigación"]), emails_example:clean(r.emails_example||r["Correos ejemplo"])
 };
}
function matrixContact(r){
 const email=lower(r.email||r["Correo"]); if(!email)return null;
 return {email,name:clean(r.name||r["Nombre"]),org:clean(r.org||r["Organización"]),position:clean(r.position||r["Puesto"]),department:clean(r.department||r["Departamento"]),domain:lower(r.domain||r["Dominio raíz"]||r["Dominio"]||(email.includes("@")?email.split("@")[1]:"")),phone:clean(r.phone||r["Teléfonos"]),classification:clean(r.classification||r["Clasificación PYME"]),confidence:clean(r.confidence||r["Confianza"]),source_files:clean(r.source_files||r["Archivos origen"])};
}
function upsertProspect(data,p){
 let x=data.prospects.find(z=>z.domain===p.domain);const stamp=now();
 if(x){Object.assign(x,Object.fromEntries(Object.entries(p).filter(([,v])=>v!==""&&v!==null&&v!==undefined)),{updated_at:stamp});return "updated";}
 data.prospects.push({id:id("PROS"),...p,stage:"PROSPECTO",owner:"JP",next_action:"",next_action_date:"",notes:"",tags:[],b2b_client_id:null,created_at:stamp,updated_at:stamp});return "added";
}
function upsertContact(data,c){
 let x=data.contacts.find(z=>z.email===c.email);const stamp=now();
 if(x){Object.assign(x,Object.fromEntries(Object.entries(c).filter(([,v])=>v!==""&&v!==null&&v!==undefined)),{updated_at:stamp});return "updated";}
 data.contacts.push({id:id("CON"),...c,notes:"",created_at:stamp,updated_at:stamp});return "added";
}
async function convertToB2B(data,prospectId,contactEmail){
 const p=data.prospects.find(x=>x.id===prospectId);if(!p)throw new Error("Prospecto no encontrado");
 const ck="clients-v1",base=await secureGet("xolum-customers-v68",ck,structuredClone(customerSeed));
 if(p.b2b_client_id && base.clients.some(c=>c.id===p.b2b_client_id)) return base.clients.find(c=>c.id===p.b2b_client_id);
 const existing=base.clients.find(c=>String(c.name||"").toLowerCase()===String(p.name||"").toLowerCase());
 if(existing){p.b2b_client_id=existing.id;p.stage="GANADO";p.updated_at=now();await write(data);return existing;}
 const clientId="CLI-CRM-"+crypto.randomBytes(4).toString("hex").toUpperCase();
 const c=data.contacts.find(x=>x.email===lower(contactEmail))||data.contacts.find(x=>x.domain===p.domain);
 const client={id:clientId,name:p.name||p.domain,status:"active",default_price_list:"B2B_STANDARD",visible_skus:"*",hidden_skus:[],hidden_price_skus:[],product_price_list_overrides:{},product_price_overrides:{},show_prices:false,budget:{type:"MONTH_CALENDAR",amount:0,scope:"PER_USER",enabled:false},approval_levels:[{from:0,to:null,level:1,label:"Autorizador nivel 1"}],users:c?.email?[{email:c.email,name:c.name||c.email,role:"buyer",budget_override:null}]:[]};
 base.clients.push(client);await secureSet("xolum-customers-v68",ck,{clients:base.clients,updated_at:now()});
 p.b2b_client_id=clientId;p.stage="GANADO";p.updated_at=now();
 data.activities.unshift({id:id("ACT"),prospect_id:p.id,type:"CONVERSION_B2B",note:`Prospecto convertido a cliente B2B ${clientId}.`,next_action:"",next_action_date:"",created_at:now()});await write(data);return client;
}

export default async(req)=>{
 const denied=requireAdmin(req);if(denied)return denied;
 const u=new URL(req.url);
 if(req.method==="GET"){const data=await read();if(u.searchParams.get("summary")==="1"){const byStage=Object.fromEntries(STAGES.map(s=>[s,data.prospects.filter(p=>p.stage===s).length]));return json({ok:true,summary:{prospects:data.prospects.length,contacts:data.contacts.length,activities:data.activities.length,opportunities:data.opportunities.length,by_stage:byStage,high_priority:data.prospects.filter(p=>String(p.priority).toLowerCase()==="alta").length,with_next_action:data.prospects.filter(p=>p.next_action_date).length,updated_at:data.updated_at}});}return json({ok:true,...data});}
 if(req.method==="DELETE"){if(u.searchParams.get("reset")!=="1")return json({ok:false,error:"reset=1 requerido"},400);await secureDelete(STORE,KEY);return json({ok:true,reset:true});}
 if(req.method!=="POST")return json({ok:false,error:"Método no permitido"},405);
 let b;try{b=await req.json()}catch{return json({ok:false,error:"JSON inválido"},400)}
 const action=clean(b.action);const data=await read();
 try{
  if(action==="importProspects"){let added=0,updated=0,skipped=0;for(const raw of arr(b.rows)){const p=matrixProspect(raw);if(!p){skipped++;continue}const r=upsertProspect(data,p);r==="added"?added++:updated++;if(p.emails_example){for(const em of p.emails_example.split(/\s*\|\s*/).map(lower).filter(x=>x.includes("@")))upsertContact(data,{email:em,name:"",org:p.name,position:"",department:"",domain:p.domain,phone:"",classification:p.classification,confidence:p.confidence,source_files:"Matriz comercial"});}}await write(data);return json({ok:true,added,updated,skipped,total:data.prospects.length});}
  if(action==="importContacts"){let added=0,updated=0,skipped=0;for(const raw of arr(b.rows)){const c=matrixContact(raw);if(!c){skipped++;continue}const r=upsertContact(data,c);r==="added"?added++:updated++;}await write(data);return json({ok:true,added,updated,skipped,total:data.contacts.length});}
  if(action==="saveProspect"){const p=b.prospect||{};let x=data.prospects.find(z=>z.id===p.id)||data.prospects.find(z=>z.domain===lower(p.domain));if(!x){x={id:id("PROS"),created_at:now(),tags:[],b2b_client_id:null};data.prospects.unshift(x)}Object.assign(x,p,{domain:lower(p.domain),stage:safeStage(p.stage),updated_at:now()});await write(data);return json({ok:true,prospect:prospectPublic(x)});}
  if(action==="saveContact"){const c=b.contact||{};let x=data.contacts.find(z=>z.id===c.id)||data.contacts.find(z=>z.email===lower(c.email));if(!x){x={id:id("CON"),created_at:now()};data.contacts.unshift(x)}Object.assign(x,c,{email:lower(c.email),domain:lower(c.domain||(String(c.email).includes("@")?String(c.email).split("@")[1]:"")),updated_at:now()});await write(data);return json({ok:true,contact:x});}
  if(action==="activity"){const p=data.prospects.find(x=>x.id===b.prospect_id);if(!p)return json({ok:false,error:"Prospecto no encontrado"},404);const a={id:id("ACT"),prospect_id:p.id,type:clean(b.type)||"NOTA",note:clean(b.note),next_action:clean(b.next_action),next_action_date:clean(b.next_action_date),created_at:now()};data.activities.unshift(a);if(a.next_action||a.next_action_date){p.next_action=a.next_action;p.next_action_date=a.next_action_date;p.updated_at=now();}await write(data);return json({ok:true,activity:a});}
  if(action==="opportunity"){const o=b.opportunity||{};let x=data.opportunities.find(z=>z.id===o.id);if(!x){x={id:id("OPP"),created_at:now()};data.opportunities.unshift(x)}Object.assign(x,o,{amount:num(o.amount),probability:num(o.probability),updated_at:now()});const p=data.prospects.find(z=>z.id===o.prospect_id);if(p&&["COTIZACION","NEGOCIACION","GANADO"].includes(safeStage(o.stage)))p.stage=safeStage(o.stage);await write(data);return json({ok:true,opportunity:x});}
  if(action==="convertB2B"){const client=await convertToB2B(data,b.prospect_id,b.contact_email);return json({ok:true,client});}
  if(action==="deleteActivity"){data.activities=data.activities.filter(x=>x.id!==b.id);await write(data);return json({ok:true});}
  return json({ok:false,error:"Acción no válida"},400);
 }catch(e){return json({ok:false,error:e.message},409)}
};

export const config={path:"/api/crm",rateLimit:{windowLimit:100,windowSize:60,aggregateBy:["ip","domain"]}};
