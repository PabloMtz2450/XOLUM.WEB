import crypto from "node:crypto";
import { getStore } from "@netlify/blobs";

function key(){
 const raw=process.env.XOLUM_DATA_ENCRYPTION_KEY||"";
 let b;try{b=Buffer.from(raw,"base64")}catch{}
 if(!b||b.length!==32) throw new Error("XOLUM_DATA_ENCRYPTION_KEY debe ser una clave base64 de 32 bytes.");
 return b;
}
function enc(value){
 const iv=crypto.randomBytes(12), cipher=crypto.createCipheriv("aes-256-gcm",key(),iv);
 const pt=Buffer.from(JSON.stringify(value)); const ct=Buffer.concat([cipher.update(pt),cipher.final()]);
 return {v:1,alg:"A256GCM",iv:iv.toString("base64"),tag:cipher.getAuthTag().toString("base64"),ct:ct.toString("base64")};
}
function dec(w){
 const d=crypto.createDecipheriv("aes-256-gcm",key(),Buffer.from(w.iv,"base64"));d.setAuthTag(Buffer.from(w.tag,"base64"));
 return JSON.parse(Buffer.concat([d.update(Buffer.from(w.ct,"base64")),d.final()]).toString("utf8"));
}
export async function secureGet(storeName,k,fallback=null){
 const s=getStore(storeName), raw=await s.get(k,{type:"json",consistency:"strong"});
 if(raw==null)return structuredClone(fallback);
 if(raw?.v===1&&raw?.alg==="A256GCM")return dec(raw);
 // Lazy migration: legacy plaintext Blob is encrypted immediately on first access.
 await s.setJSON(k,enc(raw)); return raw;
}
export async function secureSet(storeName,k,value){await getStore(storeName).setJSON(k,enc(value));return value;}
export async function secureDelete(storeName,k){return getStore(storeName).delete(k);}
export async function secureList(storeName){
 const s=getStore(storeName), {blobs}=await s.list(), out=[];
 for(const b of blobs){const x=await secureGet(storeName,b.key,null);if(x!=null)out.push(x)}return out;
}
export async function secureKeys(storeName){return (await getStore(storeName).list()).blobs.map(x=>x.key);}
