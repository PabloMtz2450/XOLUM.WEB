
import catalog from "./_data/catalog-summary.mjs";
import masterSeed from "./_data/master-v68.mjs";
import customerSeed from "./_data/customer-seed.mjs";
import {json,requireB2B,sessionInfo} from "./_auth.mjs";
import {secureGet} from "./_secure-store.mjs";
async function getJSON(store,key,fallback){return await secureGet(store,key,fallback)}
export default async(req)=>{
 if(req.method!=="GET")return json({ok:false,error:"Método no permitido"},405);
 const u=new URL(req.url),channel=(u.searchParams.get("channel")||"b2c").toLowerCase();let clientId="",email="";if(channel==="b2b"){const denied=requireB2B(req,{mutation:false});if(denied)return denied;const s=sessionInfo(req);clientId=s.client_id||"";email=String(s.email||"").toLowerCase();}
 const master=await getJSON("xolum-commerce-v68","master-data-v68",masterSeed),mm=new Map(master.map(x=>[x.sku,x]));
 let client=null,user=null;
 if(channel==="b2b"){
   const cs=await getJSON("xolum-customers-v68","clients-v1",customerSeed);
   client=cs.clients.find(x=>x.id===clientId)||null;
   if(!client)return json({ok:false,error:"Cliente B2B no configurado"},404);
   user=client.users?.find(x=>String(x.email).toLowerCase()===email)||null;
 }
 const out=[];
 for(const p of catalog){
   const m=mm.get(p.sku); if(!m||m.active===false)continue;
   if(channel==="b2c"&&!p.visible_b2c)continue;
   if(channel==="b2b"&&!p.visible_b2b)continue;
   if(channel==="b2b"){
     const visible=client.visible_skus==="*"||(Array.isArray(client.visible_skus)&&client.visible_skus.includes(p.sku));
     if(!visible||client.hidden_skus?.includes(p.sku))continue;
   }
   const list=channel==="b2c"?"B2C_PUBLIC":(client.product_price_list_overrides?.[p.sku]||client.default_price_list||"B2B_STANDARD");
   const itemPriceHidden=channel==="b2b"&&client.hidden_price_skus?.includes(p.sku);
   const show=channel==="b2c"?true:(client.show_prices!==false&&!itemPriceHidden);
   const override=channel==="b2b"?client.product_price_overrides?.[p.sku]:null;
   const price=show?(override!==undefined&&override!==null&&override!==""?Number(override):(m.price_lists?.[list]??null)):null;
   out.push({...p,price:Number.isFinite(price)?price:price===null?null:price,price_list:show?list:null,price_visible:show,stock_available:m.stock_provider==null?null:Math.max(0,(Number(m.stock_provider)||0)-(Number(m.stock_reserved)||0)),lead_time_days:m.lead_time_days??null});
 }
 return json({ok:true,channel,client:client?{id:client.id,name:client.name,budget:client.budget}:null,user,products:out});
};

export const config={path:"/api/catalog-access",rateLimit:{windowLimit:180,windowSize:60,aggregateBy:["ip","domain"]}};
