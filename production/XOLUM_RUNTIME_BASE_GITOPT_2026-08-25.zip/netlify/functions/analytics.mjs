import { getStore } from "@netlify/blobs";
import {secureGet,secureList} from "./_secure-store.mjs";
import customerSeed from "./_data/customer-seed.mjs";
import masterSeed from "./_data/master-v68.mjs";
import { json, requireAdmin } from "./_auth.mjs";
async function getJSON(store,key,fallback){return await secureGet(store,key,fallback)}
async function listOrders(){return await secureList("xolum-orders-v68")}
const num=v=>Number(v)||0;
export default async(req)=>{const denied=requireAdmin(req);if(denied)return denied;if(req.method!=="GET")return json({ok:false,error:"Método no permitido"},405);
 const [master,customers,crm,ops,orders]=await Promise.all([
   getJSON("xolum-commerce-v68","master-data-v68",masterSeed),
   getJSON("xolum-customers-v68","clients-v1",customerSeed),
   getJSON("xolum-crm-v70","crm-v1",{prospects:[],contacts:[],activities:[],opportunities:[]}),
   getJSON("xolum-operations-v80","operations-v1",{suppliers:[],price_lists:[],audit:[]}),
   listOrders()
 ]);
 const active=master.filter(x=>x.active!==false),priced=active.filter(x=>Object.values(x.price_lists||{}).some(v=>v!==null&&v!==""&&Number.isFinite(Number(v)))),costed=active.filter(x=>x.cost_provider!==null&&x.cost_provider!==""&&Number.isFinite(Number(x.cost_provider))),stockKnown=active.filter(x=>x.stock_provider!==null&&x.stock_provider!==""),pending=orders.filter(x=>x.status==="PENDING_APPROVAL"),won=(crm.prospects||[]).filter(x=>x.stage==="GANADO").length;
 const sales=orders.filter(x=>!["REJECTED","CANCELLED"].includes(x.status)).reduce((s,x)=>s+num(x.total),0);
 const byStatus={};for(const o of orders)byStatus[o.status]=(byStatus[o.status]||0)+1;
 const clientBudgets=(customers.clients||[]).map(c=>{const limit=num(c.budget?.amount);const used=orders.filter(o=>o.client_id===c.id&&!['REJECTED','CANCELLED'].includes(o.status)).reduce((s,o)=>s+num(o.total),0);return {id:c.id,name:c.name,enabled:c.budget?.enabled!==false&&limit>0,limit,used,available:Math.max(0,limit-used),users:(c.users||[]).length};});
 return json({ok:true,kpis:{products:master.length,active_products:active.length,priced:priced.length,costed:costed.length,stock_known:stockKnown.length,clients:(customers.clients||[]).length,client_users:(customers.clients||[]).reduce((s,c)=>s+(c.users||[]).length,0),prospects:(crm.prospects||[]).length,contacts:(crm.contacts||[]).length,won,suppliers:(ops.suppliers||[]).length,orders:orders.length,pending_approvals:pending.length,sales_total:sales},by_status:byStatus,budgets:clientBudgets.slice(0,100),recent_orders:orders.sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))).slice(0,12),recent_audit:(ops.audit||[]).slice(0,20)});
};
export const config={path:"/api/analytics",rateLimit:{windowLimit:100,windowSize:60,aggregateBy:["ip","domain"]}};
