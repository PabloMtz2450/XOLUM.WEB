import crypto from "node:crypto";

const COOKIE="__Host-xolum_session", CSRF="xolum_csrf";
const ADMIN_ROLES=new Set(["SUPER_ADMIN","ADMIN"]);
const B2B_ROLES=new Set(["B2B_BUYER","B2B_APPROVER","SUPER_ADMIN","ADMIN"]);

function cookieKey(){
  const raw=process.env.XOLUM_SESSION_COOKIE_KEY||"";
  let b;try{b=Buffer.from(raw,"base64")}catch{}
  if(!b||b.length!==32)throw new Error("XOLUM_SESSION_COOKIE_KEY debe ser base64 de 32 bytes");
  return b;
}
function cookies(req){return Object.fromEntries((req.headers.get("cookie")||"").split(/;\s*/).filter(Boolean).map(x=>{const i=x.indexOf("=");return [decodeURIComponent(i<0?x:x.slice(0,i)),decodeURIComponent(i<0?"":x.slice(i+1))]}))}
export function issueSession(payload){
  const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv("aes-256-gcm",cookieKey(),iv);
  const ct=Buffer.concat([cipher.update(JSON.stringify(payload),"utf8"),cipher.final()]),tag=cipher.getAuthTag();
  return `v1.${iv.toString("base64url")}.${ct.toString("base64url")}.${tag.toString("base64url")}`;
}
export function verifySessionToken(tok){
  try{const [v,iv,ct,tag]=String(tok||"").split(".");if(v!=="v1"||!iv||!ct||!tag)return null;const d=crypto.createDecipheriv("aes-256-gcm",cookieKey(),Buffer.from(iv,"base64url"));d.setAuthTag(Buffer.from(tag,"base64url"));const p=JSON.parse(Buffer.concat([d.update(Buffer.from(ct,"base64url")),d.final()]).toString("utf8"));if(!p.exp||Date.now()/1000>=p.exp)return null;return p}catch{return null}
}
export function session(req){return verifySessionToken(cookies(req)[COOKIE])}
function sameOrigin(req){const o=req.headers.get("origin");if(!o)return true;try{return new URL(o).origin===new URL(req.url).origin}catch{return false}}
function csrfOK(req){const c=cookies(req)[CSRF]||"",h=req.headers.get("x-xolum-csrf")||"";return c&&h&&c.length===h.length&&crypto.timingSafeEqual(Buffer.from(c),Buffer.from(h))}
export function json(body,status=200,extraHeaders={}){return new Response(JSON.stringify(body),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store","x-content-type-options":"nosniff","referrer-policy":"no-referrer",...extraHeaders}})}
export function requireRole(req,roles,{mutation=false}={}){const s=session(req);if(!s)return json({ok:false,error:"Sesión requerida"},401);if(!roles.has(s.role))return json({ok:false,error:"Permisos insuficientes"},403);if(mutation&&(!sameOrigin(req)||!csrfOK(req)))return json({ok:false,error:"Solicitud rechazada por protección CSRF/origen"},403);return null}
export function requireSession(req,{mutation=!['GET','HEAD','OPTIONS'].includes(req.method)}={}){const s=session(req);if(!s)return json({ok:false,error:"Sesión requerida"},401);if(mutation&&(!sameOrigin(req)||!csrfOK(req)))return json({ok:false,error:"Solicitud rechazada por protección CSRF/origen"},403);return null}
export const requireAdmin=(req,opts={})=>requireRole(req,ADMIN_ROLES,{mutation:opts.mutation??!["GET","HEAD","OPTIONS"].includes(req.method)});
export const requireB2B=(req,opts={})=>requireRole(req,B2B_ROLES,{mutation:opts.mutation??!["GET","HEAD","OPTIONS"].includes(req.method)});
export function sessionInfo(req){return session(req)}
export function cookieHeaders(token,csrf,maxAge){return [
 `${COOKIE}=${token}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Strict`,
 `${CSRF}=${csrf}; Path=/; Max-Age=${maxAge}; Secure; SameSite=Strict`
]}
export function clearCookieHeaders(){return [`${COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict`,`${CSRF}=; Path=/; Max-Age=0; Secure; SameSite=Strict`]}
export function randomToken(n=32){return crypto.randomBytes(n).toString("base64url")}
