import crypto from "node:crypto";
import {secureSet} from "./_secure-store.mjs";
import {sessionInfo} from "./_auth.mjs";
const STORE="xolum-security-audit-v81";
function clean(v,max=300){return String(v??"").replace(/[\r\n\t]+/g," ").slice(0,max)}
function ipHash(req){const ip=req.headers.get("x-nf-client-connection-ip")||req.headers.get("x-forwarded-for")?.split(',')[0]?.trim()||"";const k=process.env.XOLUM_SESSION_COOKIE_KEY||"audit";return crypto.createHmac("sha256",k).update(ip).digest("hex").slice(0,20)}
export async function auditEvent(req,event,resource,result="OK",meta={}){try{const s=sessionInfo(req),id=`${Date.now()}-${crypto.randomBytes(6).toString("hex")}`;await secureSet(STORE,id,{id,at:new Date().toISOString(),event:clean(event,80),resource:clean(resource,120),result:clean(result,40),actor:s?{email:clean(s.email,180),role:clean(s.role,40),client_id:clean(s.client_id,80)}:{email:null,role:"ANONYMOUS",client_id:null},ip_hash:ipHash(req),meta:Object.fromEntries(Object.entries(meta||{}).slice(0,20).map(([k,v])=>[clean(k,80),clean(typeof v==='object'?JSON.stringify(v):v,300)]))});}catch{/* audit must not leak or break primary operation */}}
