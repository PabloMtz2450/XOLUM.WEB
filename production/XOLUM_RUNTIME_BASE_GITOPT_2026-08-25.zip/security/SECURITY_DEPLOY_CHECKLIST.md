# Checklist de despliegue seguro — XOLUM V8.1

## 1. Antes de desplegar
- [ ] La carpeta está vinculada al Project ID correcto de XOLUM.
- [ ] Netlify CLI y Node funcionan.
- [ ] `npm install` termina correctamente.
- [ ] `VALIDAR_SEGURIDAD_V8_1.bat` termina en APROBADA.
- [ ] El viejo `XOLUM_ADMIN_TOKEN` se elimina de Netlify.

## 2. Secretos Netlify
Genera claves distintas:

```cmd
node tools\generar-secretos.mjs
```

Configura como secretos, contexto production y scope Functions:

```cmd
netlify env:set XOLUM_SESSION_COOKIE_KEY "<BASE64_32_BYTES>" --context production --scope functions --secret --force
netlify env:set XOLUM_DATA_ENCRYPTION_KEY "<OTRA_BASE64_32_BYTES>" --context production --scope functions --secret --force
netlify env:set AUTH0_CLIENT_SECRET "<SECRET_AUTH0>" --context production --scope functions --secret --force
```

Configura además:

```cmd
netlify env:set AUTH0_DOMAIN "<tenant>.auth0.com" --context production --scope functions --force
netlify env:set AUTH0_CLIENT_ID "<CLIENT_ID>" --context production --scope functions --force
netlify env:set XOLUM_SUPERADMIN_EMAIL "<correo-superadmin>" --context production --scope functions --force
netlify env:set XOLUM_SITE_URL "https://xolum.com.mx" --context production --scope functions --force
netlify env:set XOLUM_ORDER_FROM "tupedido@xolum.com.mx" --context production --scope functions --force
```

Si Brevo está activo:

```cmd
netlify env:set BREVO_API_KEY "<SECRET>" --context production --scope functions --secret --force
```

Elimina el mecanismo anterior:

```cmd
netlify env:unset XOLUM_ADMIN_TOKEN --context production
```

## 3. Auth0
- [ ] Aplicación tipo Regular Web Application.
- [ ] Callback: `https://xolum.com.mx/auth/callback`.
- [ ] Logout URL: `https://xolum.com.mx`.
- [ ] Web Origin: `https://xolum.com.mx`.
- [ ] Require Verified Email / flujo equivalente habilitado.
- [ ] WebAuthn/passkey y OTP/TOTP habilitados.
- [ ] “Customize MFA Factors using Actions” habilitado.
- [ ] `XOLUM_ENFORCE_MFA_ACTION.js` desplegada en Post Login Flow.
- [ ] Action secret `XOLUM_CLIENT_ID` coincide con la aplicación XOLUM.
- [ ] Brute-force / breached-password / bot protections de Auth0 habilitadas según el plan.

## 4. Cuentas de infraestructura
- [ ] MFA habilitado en Netlify para todos los administradores.
- [ ] MFA habilitado en Auth0 para administradores del tenant.
- [ ] MFA habilitado en Brevo/correo/DNS/repositorio cuando esté disponible.
- [ ] Sólo usuarios estrictamente necesarios tienen permisos de administración.

## 5. Draft

```cmd
netlify deploy
```

Validar en el draft:
- [ ] `/` público.
- [ ] `/tienda/` público.
- [ ] `/admin/` no entrega la consola sin sesión.
- [ ] Usuario B2C no puede abrir `/admin/`.
- [ ] Usuario B2B no puede abrir `/admin/`.
- [ ] Usuario admin requiere MFA y entra.
- [ ] API admin sin sesión devuelve 401/403.
- [ ] B2B sólo ve su empresa, catálogo y pedidos.
- [ ] B2C sólo ve sus pedidos.
- [ ] El navegador no contiene token admin, costos proveedor ni claves.

## 6. Producción

```cmd
netlify deploy --prod
```

Después del primer despliegue seguro:
1. Inicia sesión como SUPER_ADMIN con MFA.
2. Abre `/admin/seguridad.html`.
3. Ejecuta **Migrar datos heredados a cifrado**.
4. Confirma estado de claves, autenticación y migración.
5. Revisa `/admin/auditoria.html`.

## 7. Después del despliegue
- [ ] No conservar secretos en `.env`, chats, capturas o documentación pública.
- [ ] Rotar cualquier token que haya sido expuesto previamente.
- [ ] Probar recuperación de cuenta Auth0.
- [ ] Crear respaldo antes de cambios masivos.
- [ ] Programar una revisión OWASP ASVS L2/pentest externo antes de escalar información sensible.
