# XOLUM V8.1 — Modelo de seguridad

## Objetivo
Proteger la confidencialidad, integridad y disponibilidad de los datos de XOLUM, clientes B2B/B2C, prospectos, pedidos, costos y proveedores mediante defensa en profundidad. Ninguna aplicación conectada a Internet puede declararse invulnerable; esta versión reduce la superficie de ataque y falla cerrada cuando faltan controles críticos.

## Clasificación de datos

### Público
- Catálogo y descripciones aprobadas para publicación.
- Precio B2C cuando aplique.
- Contenido institucional.

### Confidencial
- Nombre, correo y teléfono de usuarios/contactos.
- Datos de empresa y configuración B2B.
- Pedidos, cotizaciones, presupuestos y autorizaciones.
- CRM y seguimientos.

### Restringido XOLUM
- Proveedores internos.
- Costos, márgenes y listas contractuales.
- Configuración administrativa y auditoría.
- Credenciales, claves criptográficas y secretos de integraciones.

## Controles implementados
- Auth0 como proveedor de identidad. XOLUM no almacena contraseñas.
- Authorization Code + PKCE, state y nonce.
- MFA obligatorio mediante Auth0 Action para la aplicación XOLUM, una vez configurado el tenant.
- Cookie de sesión `__Host-xolum_session` cifrada con AES-256-GCM, HttpOnly, Secure y SameSite=Strict.
- Sesiones administrativas de corta duración.
- RBAC server-side: SUPER_ADMIN, ADMIN, B2B_APPROVER, B2B_BUYER y B2C_USER.
- Edge gate antes de servir `/admin/*` y páginas B2B privadas.
- CSRF mediante origen mismo sitio + double-submit token en mutaciones.
- Datos confidenciales en Netlify Blobs cifrados además a nivel aplicación con AES-256-GCM.
- Claves de sesión y de datos independientes.
- Variables sensibles como secretos Netlify, nunca embebidas en frontend.
- Proveedor/costo/margen nunca se proyectan a B2C/B2B.
- Rate limiting en flujos sensibles.
- Auditoría cifrada de eventos críticos, sin almacenar IP en claro.
- Tracking de pedidos ligado a sesión, no a tokens persistentes en URL/localStorage.
- Encabezados HSTS, CSP, frame denial, no-sniff, no-referrer y Permissions-Policy.
- Semillas con datos sensibles retiradas del directorio público.
- Migración de stores heredados a cifrado de aplicación.

## Principios
- Denegar por defecto.
- Mínimo privilegio.
- Identidad derivada del servidor, nunca confiar en `email`, `client_id` o rol suministrados por el navegador.
- Una cuenta por persona; no compartir contraseñas/tokens administrativos.
- Secretos rotables y separados por propósito.
- Datos privados nunca en query string si pueden evitarse.
- Logs sin contraseñas, tokens, claves, contenido de OC o PII innecesaria.

## Riesgos residuales conocidos
1. La interfaz heredada aún conserva algunos atributos `onclick`; por compatibilidad temporal CSP permite `script-src-attr 'unsafe-inline'`. Los bloques `<script>` inline ya fueron eliminados. Debe retirarse esta excepción durante el rediseño de UI.
2. MFA depende de que Auth0 se configure exactamente según `security/auth0/README_MFA.md`; el código por sí solo no habilita factores en el tenant.
3. La seguridad de cuentas Netlify/Auth0/Brevo depende de MFA, permisos mínimos y protección de las cuentas de los administradores.
4. No se ha ejecutado un pentest externo ni un programa de bug bounty sobre esta build. Antes de manejar información de alto impacto o escalar volumen se recomienda revisión independiente basada en OWASP ASVS L2.
5. Cargas de archivos empresariales no deben persistirse públicamente. Cuando se implemente almacenamiento de OC/logos/documentos, debe ser privado, con autorización por objeto, límites de tipo/tamaño y análisis antimalware.

## Respuesta a incidentes mínima
- Rotar inmediatamente secretos comprometidos.
- Revocar sesiones/credenciales en Auth0.
- Revisar auditoría y Functions logs.
- Congelar cambios administrativos si hay sospecha de intrusión.
- Preservar evidencias y respaldos.
- Notificar conforme a obligaciones contractuales/legales aplicables.
