/**
 * XOLUM - Auth0 Post-Login Action
 * Propaga los Roles de Auth0 al ID Token mediante un claim namespaced.
 * El backend XOLUM verifica este claim criptográficamente al validar el ID Token.
 *
 * Action Secret requerido:
 *   XOLUM_CLIENT_ID = Client ID de "XOLUM Production"
 */
exports.onExecutePostLogin = async (event, api) => {
  const targetClientId = event.secrets.XOLUM_CLIENT_ID;
  if (targetClientId && event.client.client_id !== targetClientId) return;

  const roles = Array.isArray(event.authorization?.roles)
    ? event.authorization.roles.map(String)
    : [];

  api.idToken.setCustomClaim("https://xolum.com.mx/roles", roles);
};
