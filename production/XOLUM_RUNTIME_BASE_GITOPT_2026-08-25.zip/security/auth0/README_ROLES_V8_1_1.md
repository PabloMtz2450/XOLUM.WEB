# XOLUM V8.1.1 — Roles Auth0 firmados

## Por qué existe este parche
V8.1 usaba el correo `XOLUM_SUPERADMIN_EMAIL` para asignar el rol de sesión.
V8.1.1 requiere que Auth0 entregue el rol real en un claim firmado del ID Token.

Para `SUPER_ADMIN` se exigen dos condiciones:
1. Auth0 debe entregar `SUPER_ADMIN`.
2. El correo verificado debe coincidir con `XOLUM_SUPERADMIN_EMAIL`.

## Configurar la Action en Auth0

1. Auth0 Dashboard → Actions → Library → Build Custom.
2. Nombre: `XOLUM - Role Claims`
3. Trigger: `Login / Post Login`
4. Copiar `XOLUM_ROLE_CLAIMS_ACTION.js`.
5. Crear un Action Secret:
   - Key: `XOLUM_CLIENT_ID`
   - Value: Client ID de la app `XOLUM Production`
6. Deploy.
7. Actions → Triggers → post-login.
8. Arrastrar `XOLUM - Role Claims` al Flow.
9. Apply.

No despliegues `XOLUM_OPTIONAL_PAID_MFA_ACTION.js` en el plan Free.

## Validación esperada
Después de cerrar sesión y volver a entrar:
- Auth0 autentica `admin@xolum.com.mx`.
- El ID Token contiene `https://xolum.com.mx/roles = ["SUPER_ADMIN"]`.
- XOLUM valida firma, issuer, audience, nonce y correo verificado.
- Sólo entonces emite una sesión local `SUPER_ADMIN`.
