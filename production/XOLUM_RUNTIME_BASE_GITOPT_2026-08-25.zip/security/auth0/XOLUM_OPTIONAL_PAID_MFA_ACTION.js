/**
 * OPTIONAL PAID MFA - Auth0 Post-Login Action for XOLUM.
 * Use ONLY if the Auth0 plan has Pro/Enterprise MFA enabled. Requires MFA for every XOLUM login. New users must enroll first.
 * Enable WebAuthn and OTP in the Auth0 tenant and enable
 * "Customize MFA Factors using Actions" before attaching this Action.
 */
exports.onExecutePostLogin = async (event, api) => {
  const xolumClientId = event.secrets.XOLUM_CLIENT_ID;
  if (xolumClientId && event.client.client_id !== xolumClientId) return;

  const allowed = [
    { type: 'webauthn-platform' },
    { type: 'webauthn-roaming' },
    { type: 'otp' }
  ];

  const enrolled = Array.isArray(event.user.enrolledFactors)
    ? event.user.enrolledFactors.filter(f => allowed.some(a => a.type === f.type))
    : [];

  if (!enrolled.length) {
    api.authentication.enrollWithAny(allowed);
    return;
  }

  api.authentication.challengeWithAny(enrolled.map(f => ({ type: f.type })));
};
