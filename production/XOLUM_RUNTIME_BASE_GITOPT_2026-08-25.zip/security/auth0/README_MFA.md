# MFA obligatorio de XOLUM en Auth0

1. Crea/usa una **Regular Web Application** para XOLUM.
2. Habilita factores MFA: preferentemente **WebAuthn/passkeys** y **OTP/TOTP**. No uses correo como único segundo factor para administradores.
3. Crea una **Post-Login Action** y pega `XOLUM_ENFORCE_MFA_ACTION.js`.
4. Agrega a los secretos de la Action `XOLUM_CLIENT_ID` con el Client ID de la aplicación XOLUM.
5. Despliega la Action y arrástrala al Login Flow.
6. Prueba con una cuenta no administrativa primero y después con SUPER_ADMIN.
7. Habilita Attack Protection en Auth0: Brute Force Protection, Breached Password Detection y Bot Detection según el plan contratado.

La aplicación XOLUM falla cerrada si Auth0 o sus secretos no están configurados, pero la política MFA se administra en Auth0. Por eso esta Action es una parte obligatoria del despliegue, no un archivo decorativo.
