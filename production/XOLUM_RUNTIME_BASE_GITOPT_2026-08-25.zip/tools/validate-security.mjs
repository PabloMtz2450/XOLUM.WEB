import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/(.:)/,'$1')),'..');
const results=[];const add=(name,ok,detail='')=>results.push({name,ok,detail});
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])}
const source=walk(path.join(root,'public')).concat(walk(path.join(root,'netlify'))).filter(f=>/\.(html|js|mjs|ts|toml)$/.test(f));
const text=source.map(f=>fs.readFileSync(f,'utf8')).join('\n');
add('Sin token admin legado',!/(XOLUM_ADMIN_TOKEN|x-xolum-admin-token)/.test(text));
add('Sin códigos B2B compartidos',!/(x-xolum-b2b-code|xolum-b2b-access)/.test(text));
add('Sin secretos incrustados en public',!/(AUTH0_CLIENT_SECRET\s*=|BREVO_API_KEY\s*=|XOLUM_DATA_ENCRYPTION_KEY\s*=|XOLUM_SESSION_COOKIE_KEY\s*=)/.test(source.filter(f=>f.includes(path.sep+'public'+path.sep)).map(f=>fs.readFileSync(f,'utf8')).join('\n')));
add('Seeds sensibles fuera de public',!fs.existsSync(path.join(root,'public/admin/data/customer-seed.json'))&&!fs.existsSync(path.join(root,'public/admin/data/catalogo_comercial_seed.json')));
add('Cifrado de datos AES-256-GCM',fs.readFileSync(path.join(root,'netlify/functions/_secure-store.mjs'),'utf8').includes('aes-256-gcm'));
add('Cookie de sesión cifrada',fs.readFileSync(path.join(root,'netlify/functions/_auth.mjs'),'utf8').includes('aes-256-gcm'));
add('Edge gate admin',fs.readFileSync(path.join(root,'netlify/edge-functions/access-gate.ts'),'utf8').includes('/admin/'));
add('Auth0 PKCE+nonce',(()=>{const s=fs.readFileSync(path.join(root,'netlify/functions/auth-login.mjs'),'utf8');return s.includes('code_challenge')&&s.includes('nonce')})());
add('MFA/passkey documentado',fs.existsSync(path.join(root,'security/auth0/README_MFA.md'))&&fs.existsSync(path.join(root,'security/auth0/XOLUM_OPTIONAL_PAID_MFA_ACTION.js')));
add('Security audit cifrado',fs.existsSync(path.join(root,'netlify/functions/_audit.mjs'))&&fs.existsSync(path.join(root,'netlify/functions/security-audit.mjs')));
add('No inline script blocks en public',walk(path.join(root,'public')).filter(x=>x.endsWith('.html')).every(f=>!/<script(?![^>]*\bsrc=)[^>]*>/i.test(fs.readFileSync(f,'utf8'))));
let syntax=true,bad='';for(const f of source.filter(f=>/\.(js|mjs)$/.test(f))){try{execFileSync(process.execPath,['--check',f],{stdio:'ignore'})}catch{syntax=false;bad=path.relative(root,f);break}}add('Sintaxis JS/MJS',syntax,bad);
const failed=results.filter(x=>!x.ok);const report={version:'8.1-security-hardened',passed:failed.length===0,checked_at:new Date().toISOString(),results,known_residuals:["Legacy UI todavía usa algunos atributos onclick; CSP mantiene script-src-attr 'unsafe-inline' por compatibilidad. Refactor visual posterior debe eliminar estos handlers y cambiar script-src-attr a 'none'.","La política MFA depende de configurar correctamente Auth0 y desplegar la Action incluida.","Ningún sistema público puede declararse invulnerable; se recomienda pentest externo antes de procesar información de alto impacto."]};fs.writeFileSync(path.join(root,'VALIDACION_SEGURIDAD_V8_1.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));process.exitCode=failed.length?1:0;
