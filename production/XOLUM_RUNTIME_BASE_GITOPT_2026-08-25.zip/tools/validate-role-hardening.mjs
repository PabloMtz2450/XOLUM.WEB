import fs from "node:fs";
const cb=fs.readFileSync("netlify/functions/auth-callback.mjs","utf8");
const action=fs.readFileSync("security/auth0/XOLUM_ROLE_CLAIMS_ACTION.js","utf8");
const checks={
  callback_reads_namespaced_roles: cb.includes('payload["https://xolum.com.mx/roles"]'),
  callback_requires_auth0_superadmin_role: cb.includes('auth0Roles.includes("SUPER_ADMIN")'),
  callback_secondary_superadmin_email_check: cb.includes('SUPER_ADMIN no coincide con la identidad administrativa autorizada'),
  session_carries_roles: cb.includes("auth0_roles:auth0Roles"),
  action_sets_namespaced_claim: action.includes('api.idToken.setCustomClaim("https://xolum.com.mx/roles", roles)'),
  action_reads_auth0_authorization_roles: action.includes("event.authorization?.roles"),
  legacy_email_only_admin_assignment_removed: !cb.includes('if(email===String(process.env.XOLUM_SUPERADMIN_EMAIL')
};
console.log(JSON.stringify(checks,null,2));
if(Object.values(checks).some(v=>!v)) process.exit(1);
console.log("\\nROLE HARDENING: APROBADO");
