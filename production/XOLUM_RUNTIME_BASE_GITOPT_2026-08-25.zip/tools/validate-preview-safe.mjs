import fs from "node:fs";
const origin=fs.readFileSync("netlify/functions/_origin.mjs","utf8");
const login=fs.readFileSync("netlify/functions/auth-login.mjs","utf8");
const cb=fs.readFileSync("netlify/functions/auth-callback.mjs","utf8");
const toml=fs.readFileSync("netlify.toml","utf8");
const checks={
  preview_bound_to_exact_project: origin.includes("--euphonious-crisp-9e0050.netlify.app"),
  preview_origin_validated: origin.includes("Origen XOLUM no autorizado"),
  login_uses_request_origin: login.includes("allowedAppOrigin(req)"),
  callback_uses_request_origin: cb.includes("allowedAppOrigin(req)"),
  login_no_longer_requires_site_env: !login.includes("process.env.XOLUM_SITE_URL"),
  callback_no_longer_requires_site_env: !cb.includes("process.env.XOLUM_SITE_URL"),
  crm_redirect_present: toml.includes('from = "/api/crm"'),
  session_redirect_present: toml.includes('from = "/api/session"')
};
console.log(JSON.stringify(checks,null,2));
if(Object.values(checks).some(v=>!v)) process.exit(1);
console.log("\nPREVIEW SAFE: APROBADO");
